

$('head').append('<script type="text/javascript" src="https://test/sc.js"></script>');


define(['jquery'], function($){
    var CustomWidget = function () {
    	var self = this;
		this.callbacks = {
			render: function(){
				console.log('render6664');
				$(document).ajaxSuccess(function (event, xhr, settings) {
					var mas_elem={};
					console.log (settings.url);
						 //если загружена форма записи формул
						 if (settings.url.indexOf('modal') != 1) 
						 {
									//кнопка сохранить
							  $('.button-input.button-input-disabled.js-communications-template-save').click(function()
							  {
								  console.log('good6667');
								  //поле вывода результата
								  var out=$('.amoforms__tab-editor-left').find('input').val();
								  //поле ввода формулы
								  var input=$('.amoforms__tab-editor-left').find('textarea').val();
									console.dir(self.get_settings())
										//выгружаем данные 
									var mas_elem=self.get_settings().formul;
											
										try
										{
											console.log(out,input);
											//console.log(JSON.parse(mas_elem).length);
											console.dir(JSON.parse(mas_elem));
											console.dir(self.get_settings().formul);
											//mas_elem[mas_elem.length]={'out':out,'formula':input};
											$.post( "https://ikutin.amocrm.ru/ajax/widgets/edit", { action: 'edit',
													'id': '344911',
													'code': 'formula1',
													'widget_active':self.get_settings().widget_active,
													'settings[login]': self.get_settings().login,
													'settings[api_key]': self.get_settings().api_key,
													'settings[account]': self.get_settings().account,
												'settings[formul]':'{["out":'+'"'+out+'"'+',"formula":'+'"'+input+'"'+']}' });
											
										}
										catch(e)
										{
											console.log(out,input)
												//если изначально ничего не было в памяти
											//self.set_settings({'formul':[{'out':out,'formula':input}]});
											//	$.post( "https://ikutin.amocrm.ru/ajax/widgets/edit", { 'action': 'edit', 'formul':{'out':out,'formula':input}});
												
												$.post( "https://ikutin.amocrm.ru/ajax/widgets/edit", { action: 'edit',
													'id': '344911',
													'code': 'formula1',
													'widget_active':self.get_settings().widget_active,
													'settings[login]': self.get_settings().login,
													'settings[api_key]': self.get_settings().api_key,
													'settings[account]': self.get_settings().account,
													 'settings[formul]':'{["out":'+'"'+out+'"'+',"formula":'+'"'+input+'"'+']}' });
										
										}

								 
								  console.log(JSON.stringify(mas_elem))
								  
									
							  }
							)
						 }
				})
					

				return true;
			},
			init: function(){
				return true;

			},
			bind_actions: function(){
				console.log('bind_1');
		
				return true;
			},
			settings: function(){
				return true;
			},
			onSave: function(){
				alert('click');
				return true;
			},
			destroy: function(){
				
			},
			contacts: {
					//select contacts in list and clicked on widget name
					selected: function(){
						console.log('contacts');
					}
				},
			leads: {
					//select leads in list and clicked on widget name
					selected: function(){
						console.log('leads');
					}
				},
			tasks: {
					//select taks in list and clicked on widget name
					selected: function(){
						console.log('tasks');
					}
				}
		};
		return this;
    };

return CustomWidget;
});